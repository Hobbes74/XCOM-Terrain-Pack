UFO2000 Apartment Terrain version 9.04 by Hobbes

To install simply unzip the entire contents of the zipped file to the /newmaps directory of your UFO2000 directory. This terrain only requires the X-COM:UFO Demo to be installed in order to be playable.

Have fun :)

The lastest version can be found at http://area51.xcomufo.com

Hobbes

