UFO2000 Modified Farm Terrain version 9.03 by Hobbes

To install simply unzip the entire contents of the zipped file to the /newmaps directory of your UFO2000 directory. This terrain requires the full version of X-Com: UFO Defense to be installed with UFO2000. 

Have fun :)

The lastest version can be found at http://area51.xcomufo.com

Hobbes

