AddXcomTerrain {
	Name = "Area 51",
	Tiles =		{
		"$(xcom)/terrain/blanks.*",
		"$(ufo2000)/newmaps/area/area51a.*",
		"$(ufo2000)/newmaps/area/area51b.*",
		"$(ufo2000)/newmaps/area/area51c.*",
		"$(ufo2000)/newmaps/area/area51d.*",
		"$(ufo2000)/newmaps/area/area51e.*"
	},
	Maps = {
		"$(ufo2000)/newmaps/area/area00.map",
		"$(ufo2000)/newmaps/area/area01.map",
		"$(ufo2000)/newmaps/area/area02.map",
		"$(ufo2000)/newmaps/area/area03.map",
		"$(ufo2000)/newmaps/area/area04.map",
		"$(ufo2000)/newmaps/area/area05.map",
		"$(ufo2000)/newmaps/area/area06.map",
		"$(ufo2000)/newmaps/area/area07.map",
		"$(ufo2000)/newmaps/area/area08.map",
		"$(ufo2000)/newmaps/area/area09.map",
		"$(ufo2000)/newmaps/area/area10.map",
		"$(ufo2000)/newmaps/area/area11.map",
		"$(ufo2000)/newmaps/area/area12.map",
		"$(ufo2000)/newmaps/area/area13.map",
		"$(ufo2000)/newmaps/area/area14.map",
		"$(ufo2000)/newmaps/area/area15.map",
		"$(ufo2000)/newmaps/area/area16.map",
		"$(ufo2000)/newmaps/area/area17.map",
		"$(ufo2000)/newmaps/area/area18.map",
		"$(ufo2000)/newmaps/area/area19.map",
		"$(ufo2000)/newmaps/area/area20.map",
		"$(ufo2000)/newmaps/area/area21.map",
		"$(ufo2000)/newmaps/area/area22.map",
		"$(ufo2000)/newmaps/area/area23.map",
		"$(ufo2000)/newmaps/area/area24.map",
		"$(ufo2000)/newmaps/area/area25.map",
		"$(ufo2000)/newmaps/area/area26.map",
		"$(ufo2000)/newmaps/area/area27.map",
		"$(ufo2000)/newmaps/area/area28.map",
		"$(ufo2000)/newmaps/area/area29.map",
		"$(ufo2000)/newmaps/area/area30.map",
		"$(ufo2000)/newmaps/area/area31.map",
		"$(ufo2000)/newmaps/area/area32.map",
		"$(ufo2000)/newmaps/area/area33.map",
		"$(ufo2000)/newmaps/area/area34.map",
		"$(ufo2000)/newmaps/area/area35.map",
		"$(ufo2000)/newmaps/area/area36.map",
		"$(ufo2000)/newmaps/area/area37.map",
		"$(ufo2000)/newmaps/area/area38.map",
		"$(ufo2000)/newmaps/area/area39.map",
		"$(ufo2000)/newmaps/area/area40.map",
		"$(ufo2000)/newmaps/area/area41.map",
		"$(ufo2000)/newmaps/area/area42.map",
		"$(ufo2000)/newmaps/area/area43.map",
		"$(ufo2000)/newmaps/area/area44.map",
		"$(ufo2000)/newmaps/area/area45.map",
		"$(ufo2000)/newmaps/area/area46.map",
		"$(ufo2000)/newmaps/area/area47.map",
		"$(ufo2000)/newmaps/area/area48.map",
		"$(ufo2000)/newmaps/area/area49.map",
		"$(ufo2000)/newmaps/area/area50.map"
	},

MapGenerator = function(tmp)
		local function add_roads(size_x, size_y, map)
			local x, y, w, z
	
			if (math.random(1, size_x) ~= 1) then
				x = math.random(1, size_x)
				for i = 1, size_y do map[x][i] = random {01, 04, 05, 06, 48} end
			end
	
			if (math.random(1, size_y) > 2) then
				y = math.random(1, size_y)
				for i = 1, size_x do map[i][y] = random {40, 41, 42} end
			end


			if (math.random(1, size_y) ~= 1) then
				w = math.random(1, size_y)
				for i = 1, size_x do map[i][w] = random {00, 07, 08, 49, 50} end
			end

			if (math.random(1, size_x) > 2) then
				z = math.random(1, size_x)
				for i = 1, size_y do map[z][i] = random {43, 44, 45} end
			end

			if (x and y) then
				map[x][y] = 3
			end

			
			if (x and w) then
				map[x][w] = 2
			end

			if (v and y) then
				map[v][y] = 3
			end
	
			if (v and w) then
				map[v][w] = 2
			end

			if (z and y) then
				map[z][y] = 47
			end

			
			if (z and w) then
				map[z][w] = 46
			end

			if (u and y) then
				map[u][y] = 47
			end

			
			if (u and w) then
				map[u][w] = 46
			end

		end

		local function random_normal()
			return random {25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39}
		end	

		local function random_double(x, y, map)
			local a = x + 1
			local b = y + 1
			if (map[x][y] > 8 and map[a][y] > 8 and map[x][b] > 8 and map[a][b] > 8 and  map[x][y] < 40 and map[a][y] < 40 and map[x][b] < 40 and map[a][b] < 40) then
				map[x][y] = random {13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24}
				map[a][y] = -1
				map[x][b] = -1
				map[a][b] = -1
			end
		end

		local function random_triple(x, y, map)
			local a = x + 1
			local b = y + 1
			local c = x + 2
			local d = y + 2

			if (map[x][y] > 8 and map[a][y] > 8 and map[x][b] > 8 and map[a][b] > 8 and map[c][y] > 24 and map[c][b] > 24 and map[x][d] > 24 and map[a][d] > 24 and map[c][d] > 24 and  map[x][y] < 40 and map[a][y] < 40 and map[x][b] < 40 and map[a][b] < 40 and map[c][y] < 40 and map[c][b] < 40 and map[x][d] < 40 and map[a][d] < 40 and map[c][d] < 40) then
				map[x][y] = random {09, 10, 11, 12}
				map[a][y] = -1
				map[x][b] = -1
				map[a][b] = -1
				map[c][y] = -1
				map[x][d] = -1
				map[a][d] = -1
				map[c][b] = -1
				map[c][d] = -1
			end
		end


		for i = 1, tmp.SizeY do
			for j = 1, tmp.SizeX do
				tmp.Mapdata[i][j] = random_normal()
			end
		end

		add_roads(tmp.SizeX, tmp.SizeY, tmp.Mapdata)

		for i = 1, tmp.SizeY - 1 do
			for j = 1, tmp.SizeX - 1 do
				if (math.random(1, 12) > 8) then
					random_double(i, j, tmp.Mapdata)
				end
			end
		end

		for i = 1, tmp.SizeY - 2 do
			for j = 1, tmp.SizeX - 2 do
				if (math.random(1, 12) > 2) then
					random_triple(i, j, tmp.Mapdata)
				end
			end
		
		end

		return tmp
	end		
}
