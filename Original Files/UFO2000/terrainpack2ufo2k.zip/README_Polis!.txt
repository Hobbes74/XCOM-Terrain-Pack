UFO2000 Polis Terrain version 9.02

This terrain requires the UFO Demo or the full versionto be installed with UFO2000. To play 
the new terrain simply unzip this file into the /newmaps directory 
inside the UFO2000 directory. 
