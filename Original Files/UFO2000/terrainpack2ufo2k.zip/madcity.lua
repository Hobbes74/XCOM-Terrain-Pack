AddXcomTerrain {
	Name = "Mad City",
	Tiles =	{
		"$(xcom)/terrain/blanks.*",
		"$(xcom)/terrain/roads.*",
		"$(xcom)/terrain/urbits.*",
		"$(xcom)/terrain/urban.*",
		"$(xcom)/terrain/frniture.*"
	},
	Maps = {
		"$(xcom)/maps/urban00.map",
		"$(xcom)/maps/urban01.map",
		"$(xcom)/maps/urban02.map",
		"$(xcom)/maps/urban03.map",
		"$(xcom)/maps/urban04.map",
		"$(xcom)/maps/urban05.map",
		"$(xcom)/maps/urban06.map",
		"$(xcom)/maps/urban07.map",
		"$(xcom)/maps/urban08.map",
		"$(xcom)/maps/urban09.map",
		"$(xcom)/maps/urban14.map",
		"$(xcom)/maps/urban15.map",
		"$(xcom)/maps/urban16.map",
		"$(xcom)/maps/urban17.map",
		"$(xcom)/maps/urban18.map",
		"$(ufo2000)/newmaps/madcity/urban10.map",
		"$(ufo2000)/newmaps/madcity/urban11.map",
		"$(ufo2000)/newmaps/madcity/urban12.map",
		"$(ufo2000)/newmaps/madcity/urban13.map",
		"$(ufo2000)/newmaps/madcity/urban27.map",
		"$(ufo2000)/newmaps/madcity/urban28.map",
		"$(ufo2000)/newmaps/madcity/urban29.map",
		"$(ufo2000)/newmaps/madcity/urban30.map",
		"$(ufo2000)/newmaps/madcity/urban31.map",
		"$(ufo2000)/newmaps/madcity/urban32.map",
		"$(ufo2000)/newmaps/madcity/urban33.map",
		"$(ufo2000)/newmaps/madcity/urban34.map",
		"$(ufo2000)/newmaps/madcity/urban35.map",
		"$(ufo2000)/newmaps/madcity/urban36.map",
		"$(ufo2000)/newmaps/madcity/urban37.map",
		"$(ufo2000)/newmaps/madcity/urban38.map",
		"$(ufo2000)/newmaps/madcity/urban39.map",
		"$(ufo2000)/newmaps/madcity/urban40.map",
		"$(ufo2000)/newmaps/madcity/urban41.map",
		"$(ufo2000)/newmaps/madcity/urban42.map",
		"$(ufo2000)/newmaps/madcity/urban43.map",
		"$(ufo2000)/newmaps/madcity/urban44.map",
		"$(ufo2000)/newmaps/madcity/urban45.map",
		"$(ufo2000)/newmaps/madcity/urban46.map",
		"$(ufo2000)/newmaps/madcity/urban47.map"
	},
	MapGenerator = function(tmp)

		local function add_roads(size_x, size_y, map)
			local x, y
	
			if (math.random(1, size_x) ~= 1) then
				x = math.random(1, size_x)
				for i = 1, size_y do map[x][i] = 1 end
			end
	
			if (math.random(1, size_y) ~= 1) then
				y = math.random(1, size_y)
				for i = 1, size_x do map[i][y] = 0 end
			end
	
			if (x and y) then
				map[x][y] = 2
			end
		end

		local function random_normal()
			return random {03, 04, 10, 14, 15, 16, 17, 18, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47}
		end	

		local function random_double(x, y, map)
			local a = x + 1
			local b = y + 1
			if (map[x][y] > 2 and map[a][y] > 2 and map[x][b] > 2 and map[a][b] > 2) then
				map[x][y] = random {05, 06, 07, 08, 09, 11, 12, 13, 27, 28, 29, 30, 31, 32, 33, 34, 35}
				map[a][y] = -1
				map[x][b] = -1
				map[a][b] = -1
			end
		end


		for i = 1, tmp.SizeY do
			for j = 1, tmp.SizeX do
				tmp.Mapdata[i][j] = random_normal()
			end
		end

		add_roads(tmp.SizeX, tmp.SizeY, tmp.Mapdata)

		for i = 1, tmp.SizeY - 1 do
			for j = 1, tmp.SizeX - 1 do
				if (math.random(1, 12) > 8) then
					random_double(i, j, tmp.Mapdata)
				end
			end
		end

		return tmp
		end

}
