UFO2000 Skyranger Factory terrain version 9.00 by Hobbes released 15/8/05

To install simply unzip the entire contents of the zipped file to the /newmaps directory of your UFO2000 directory. This terrain doesn't require any of the original X-Com terrains so it can be installed with simply the X-Com: UFO Defense Demo.

Warning: The Skyranger Hangar requires Area51 terrain to be also installed. 

Have fun :)

The lastest version can be found at http://area51.xcomufo.com

Hobbes

