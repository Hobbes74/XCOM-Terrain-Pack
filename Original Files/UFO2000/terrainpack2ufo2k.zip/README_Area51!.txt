UFO2000 Area 51 terrain version 9.52 by Hobbes released 15/8/05

Before installing it is advisable to remove (simply delete the /area folder and the area51.lua files) any previous versions. 

To install simply unzip the entire contents of the zipped file to the /newmaps directory of your UFO2000 directory. This terrain doesn't require any of the original X-Com terrains so it can be installed with simply the X-Com: UFO Defense Demo.

This package includes Area 51 plus the Skyranger Hangar terrain (version 9.00). 

Have fun :)

The lastest version can be found at http://area51.xcomufo.com

Hobbes

