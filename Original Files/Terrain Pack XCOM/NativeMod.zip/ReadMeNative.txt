X-COM: UFO Defense Native Mod Version 9.01 by Hobbes

Requirements: XComUtil version 9.60 Beta version (you can download it at 
http://xcomutil.scotttjones.com/)

Warning: before unzipping make a copy of the XComUtil.cfg file if you want to restore later XComUtil's settings (or reinstall it). 

This mod replaces the Mars terrain by a "tropical village". To play, first unzip the mod to your UFO folder. Afterwards run xcusetup and on the option of ""Do you wish to be prompted before a ship attack" you must choose Yes.

Use RunXCom.bat to start UFO. When the plane lands for a ground mission the prompt window will appear before the equip screen. Choose number 9, "Mars". 

Have fun :)

The lastest version can be found at: www.xcomufo.com/area51/

Hobbes

