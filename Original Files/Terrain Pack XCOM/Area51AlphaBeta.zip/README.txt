X-COM: UFO Defense Area 51 Alpha Beta Mod by Hobbes

WARNING: This mod will replace files on the Terrain, Routes and Maps
directories so remember to make back ups of these folders if you 
wish later to return to the game's original configuration (or you can
reinstall it from the game disks). There shouldn't be any problems
but use these files at your own risk. 

Unzip the mod to your UFO folder and click Yes to All when it asks you if you 
want to replace the files.

Run XCSetup (remember you'll need to download and install version 9.51 
Beta or higher). 
On the option "Do you wish combat terrain to be randomized?" choose No 
and, on "Do you wish to be prompted before a ship attack" you must 
choose Yes.

Click on RunXCom to start the game. Send a plane to a Terror site or to a Large 
UFO landed/crashed and when the prompt appears choose terrain 5 - Urban.

Have fun :)

The lastest version can be found at: www.geocities.com/
aadlg/xcom.html

Hobbes

