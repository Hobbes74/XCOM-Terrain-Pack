AddXcomTerrain {
	Name = "Farm with UFOs",
	Tiles = {
		"$(xcom)/terrain/blanks.*",
		"$(xcom)/terrain/u_ext02.*",
		"$(xcom)/terrain/u_wall02.*",
		"$(xcom)/terrain/U_bits.*",
		"$(xcom)/terrain/u_disec2.*",
		"$(xcom)/terrain/u_oper2.*",
		"$(xcom)/terrain/u_pods.*",
		"$(xcom)/terrain/cultivat.*",
		"$(xcom)/terrain/barn.*",
		"$(xcom)/terrain/ufo1.*"
	},
	Maps = {
		"$(ufo2000)/newmaps/ufof/ufof00.map",
		"$(ufo2000)/newmaps/ufof/ufof01.map",
		"$(ufo2000)/newmaps/ufof/ufof02.map",
		"$(ufo2000)/newmaps/ufof/ufof03.map",
		"$(ufo2000)/newmaps/ufof/ufof04.map",
		"$(ufo2000)/newmaps/ufof/ufof05.map",
		"$(ufo2000)/newmaps/ufof/ufof06.map",
		"$(ufo2000)/newmaps/ufof/ufof07.map",
		"$(ufo2000)/newmaps/ufof/ufof10.map",
		"$(ufo2000)/newmaps/ufof/ufof11.map",
		"$(ufo2000)/newmaps/ufof/ufof12.map",
		"$(ufo2000)/newmaps/ufof/ufof13.map",
		"$(ufo2000)/newmaps/ufof/ufof14.map",
		"$(ufo2000)/newmaps/ufof/ufof15.map",
		"$(ufo2000)/newmaps/ufof/ufof16.map",
		"$(ufo2000)/newmaps/ufof/ufof17.map",
		"$(ufo2000)/newmaps/ufof/ufof18.map",
		"$(ufo2000)/newmaps/ufof/ufof19.map",
		"$(ufo2000)/newmaps/ufof/ufof20.map",
		"$(ufo2000)/newmaps/ufof/ufof21.map",
		"$(ufo2000)/newmaps/ufof/ufof22.map",
		"$(ufo2000)/newmaps/ufof/ufof23.map",
		"$(ufo2000)/newmaps/ufof/ufof24.map",
		"$(ufo2000)/newmaps/ufof/ufof25.map",
		"$(ufo2000)/newmaps/ufof/ufof26.map",
		"$(ufo2000)/newmaps/ufof/ufof27.map",
		"$(ufo2000)/newmaps/ufof/ufof28.map"


	},

	MapGenerator = function(tmp)
		local function add_ufos(size_x, size_y, map)
			
			local random_number = math.random (1, 8)

			if random_number == 1 then
				local x = math.random(1, size_x)
				local y = math.random(1, size_y)
				map[x][y] = 1
			end

			if random_number == 2 then
				local x = math.random(1, (size_x - 2))
				local y = math.random(1, (size_y - 2))
				local a = (x + 1)
				local b = (y + 1)
				map[x][y] = 2
				map[x][b] = -1
				map[a][y] = -1
				map[a][b] = -1
			end

			if random_number == 3 then
				local x = math.random(1, (size_x - 2))
				local y = math.random(1, (size_y - 2))
				local a = (x + 1)
				local b = (y + 1)
				map[x][y] = 3
				map[x][b] = -1
				map[a][y] = -1
				map[a][b] = -1
			end


			if random_number == 4 then
				local x = math.random(1, (size_x - 2))
				local y = math.random(1, (size_y - 2))
				local a = (x + 1)
				local b = (y + 1)
				map[x][y] = 4
				map[x][b] = -1
				map[a][y] = -1
				map[a][b] = -1
			end

			
			if random_number == 5 then
				local x = math.random(1, (size_x - 3))
				local y = math.random(1, (size_y - 2))
				local a = (x + 1)
				local b = (y + 1)
				local c = (x + 2)
				map[x][y] = 5
				map[x][b] = -1
				map[a][y] = -1
				map[a][b] = -1
				map[c][y] = -1
				map[c][b] = -1
				
			end

			if random_number == 6 then
				local x = math.random(1, (size_x - 3))
				local y = math.random(1, (size_y - 3))
				local a = (x + 1)
				local b = (y + 1)
				local c = (x + 2)
				local d = (y + 2)
				map[x][y] = 6
				map[x][b] = -1
				map[a][y] = -1
				map[a][b] = -1
				map[c][y] = -1
				map[c][b] = -1
				map[x][d] = -1
				map[a][d] = -1
				map[c][d] = -1
			end

			if random_number == 7 then
				local x = math.random(1, (size_x - 3))
				local y = math.random(1, (size_y - 2))
				local a = (x + 1)
				local b = (y + 1)
				local c = (x + 2)
				map[x][y] = 7
				map[x][b] = -1
				map[a][y] = -1
				map[a][b] = -1
				map[c][y] = -1
				map[c][b] = -1

			end

			if random_number == 8 then
				local x = math.random(1, size_x)
				local y = math.random(1, size_y)
				map[x][y] = 0
			end

		end

						
		local function random_normal()
			return random {10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22,              23, 24, 25, 26, 27, 28}

		end

		for i = 1, tmp.SizeY do
			for j = 1, tmp.SizeX do
				tmp.Mapdata[i][j] = random_normal()
			end
		end

		add_ufos(tmp.SizeX, tmp.SizeY, tmp.Mapdata)


		return tmp
	end

}