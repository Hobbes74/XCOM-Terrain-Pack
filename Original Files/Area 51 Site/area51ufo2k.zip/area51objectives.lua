AddXcomTerrain {
	Name = "Area 51 - Objectives",
	Tiles =		{
		"$(xcom)/terrain/blanks.*",
		"$(ufo2000)/newmaps/area/roads.*",
		"$(ufo2000)/newmaps/area/urbits.*",
		"$(ufo2000)/newmaps/area/urban.*",
		"$(ufo2000)/newmaps/area/frniture.*",
		"$(ufo2000)/newmaps/area/u_base.*"
	},
	Maps = {
		"$(ufo2000)/newmaps/area/area50.map",
		"$(ufo2000)/newmaps/area/area51.map",
		"$(ufo2000)/newmaps/area/area52.map",
		"$(ufo2000)/newmaps/area/area53.map",
		"$(ufo2000)/newmaps/area/area54.map",
		"$(ufo2000)/newmaps/area/area55.map",
		"$(ufo2000)/newmaps/area/area27.map",
		"$(ufo2000)/newmaps/area/area29.map",
		"$(ufo2000)/newmaps/area/area30.map",
		"$(ufo2000)/newmaps/area/area31.map",
		"$(ufo2000)/newmaps/area/area38.map"
	}		
}
