AddXcomTerrain {
	Name = "Area 51 - Standard",
	Tiles =		{
		"$(xcom)/terrain/blanks.*",
		"$(ufo2000)/newmaps/area/roads.*",
		"$(ufo2000)/newmaps/area/urbits.*",
		"$(ufo2000)/newmaps/area/urban.*",
		"$(ufo2000)/newmaps/area/frniture.*",
		"$(ufo2000)/newmaps/area/u_base.*"
	},
	Maps = {
		"$(ufo2000)/newmaps/area/area00.map",
		"$(ufo2000)/newmaps/area/area01.map",
		"$(ufo2000)/newmaps/area/area02.map",
		"$(ufo2000)/newmaps/area/area03.map",
		"$(ufo2000)/newmaps/area/area04.map",
		"$(ufo2000)/newmaps/area/area05.map",
		"$(ufo2000)/newmaps/area/area06.map",
		"$(ufo2000)/newmaps/area/area07.map",
		"$(ufo2000)/newmaps/area/area08.map",
		"$(ufo2000)/newmaps/area/area09.map",
		"$(ufo2000)/newmaps/area/area10.map",
		"$(ufo2000)/newmaps/area/area11.map",
		"$(ufo2000)/newmaps/area/area12.map",
		"$(ufo2000)/newmaps/area/area13.map",
		"$(ufo2000)/newmaps/area/area14.map",
		"$(ufo2000)/newmaps/area/area15.map",
		"$(ufo2000)/newmaps/area/area16.map",
		"$(ufo2000)/newmaps/area/area17.map",
		"$(ufo2000)/newmaps/area/area18.map",
		"$(ufo2000)/newmaps/area/area19.map",
		"$(ufo2000)/newmaps/area/area20.map",
		"$(ufo2000)/newmaps/area/area21.map",
		"$(ufo2000)/newmaps/area/area22.map",
		"$(ufo2000)/newmaps/area/area23.map",
		"$(ufo2000)/newmaps/area/area24.map",
		"$(ufo2000)/newmaps/area/area25.map",
		"$(ufo2000)/newmaps/area/area26.map",
		"$(ufo2000)/newmaps/area/area27.map",
		"$(ufo2000)/newmaps/area/area28.map",
		"$(ufo2000)/newmaps/area/area29.map",
		"$(ufo2000)/newmaps/area/area30.map",
		"$(ufo2000)/newmaps/area/area31.map",
		"$(ufo2000)/newmaps/area/area32.map",
		"$(ufo2000)/newmaps/area/area33.map",
		"$(ufo2000)/newmaps/area/area34.map",
		"$(ufo2000)/newmaps/area/area35.map",
		"$(ufo2000)/newmaps/area/area36.map",
		"$(ufo2000)/newmaps/area/area37.map",
		"$(ufo2000)/newmaps/area/area38.map",
		"$(ufo2000)/newmaps/area/area39.map"
	},

MapGenerator = function(tmp)
		local function add_roads(size_x, size_y, map)
			local x, y, w
	
			if (math.random(1, size_x) ~= 1) then
				x = math.random(1, size_x)
				for i = 1, size_y do map[x][i] = random {01, 05, 06} end
			end
	
			if (math.random(1, size_y) ~= 1) then
				y = math.random(1, size_y)
				for i = 1, size_x do map[i][y] = random {00, 07, 08} end
			end


			if (math.random(1, size_y) ~= 1) then
				w = math.random(1, size_y)
				for i = 1, size_x do map[i][w] = random {00, 07, 08} end
			end

			if (x) then
				map[x][1] = 3
				map[x][size_y] = 4
			end

			if (x and y) then
				map[x][y] = 2
			end

			
			if (x and w) then
				map[x][w] = 2
			end

		end

		local function random_normal()
			return random {25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39}
		end	

		local function random_double(x, y, map)
			local a = x + 1
			local b = y + 1
			if (map[x][y] > 8 and map[a][y] > 8 and map[x][b] > 8 and map[a][b] > 8) then
				map[x][y] = random {13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24}
				map[a][y] = -1
				map[x][b] = -1
				map[a][b] = -1
			end
		end

		local function random_triple(x, y, map)
			local a = x + 1
			local b = y + 1
			local c = x + 2
			local d = y + 2

			if (map[x][y] > 8 and map[a][y] > 8 and map[x][b] > 8 and map[a][b] > 8) and map[c][y] > 24 and map[c][b] > 24 and map[x][d] > 24 and map[a][d] > 24 and map[c][d] > 24 
then
				map[x][y] = random {09, 10, 11, 12}
				map[a][y] = -1
				map[x][b] = -1
				map[a][b] = -1
				map[c][y] = -1
				map[x][d] = -1
				map[a][d] = -1
				map[c][b] = -1
				map[c][d] = -1
			end
		end


		for i = 1, tmp.SizeY do
			for j = 1, tmp.SizeX do
				tmp.Mapdata[i][j] = random_normal()
			end
		end

		add_roads(tmp.SizeX, tmp.SizeY, tmp.Mapdata)

		for i = 1, tmp.SizeY - 1 do
			for j = 1, tmp.SizeX - 1 do
				if (math.random(1, 12) > 8) then
					random_double(i, j, tmp.Mapdata)
				end
			end
		end

		for i = 1, tmp.SizeY - 2 do
			for j = 1, tmp.SizeX - 2 do
				if (math.random(1, 12) > 4) then
					random_triple(i, j, tmp.Mapdata)
				end
			end
		
		end

		return tmp
	end		
}
