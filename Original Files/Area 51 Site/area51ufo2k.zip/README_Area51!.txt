UFO2000 Area 51 Terrains version 9.02 by Hobbes

To install simply unzip the entire contents of the zipped file to the /newmaps directory of your UFO2000 directory. This terrain doesn't require any of the original X-Com terrains so it can be installed with simply the X-Com: UFO Defense Demo.

Area 51 consists of 5 different terrains, each described below:

Standard: Air Base setting with runways and all sorts of buildings (hangar, control tower, bunker, etc.)
Complex: Industrial-military facility
Objectives: 6 large buildings (HWP Factory, Prison, Oil Depot, etc.)
Skyranger Factory: a single 60x60 building (it can only be played at this size)
Assault: Combat training range

Have fun :)

The lastest version can be found at http://area51.xcomufo.com

Hobbes

