AddXcomTerrain {
	Name = "Area 51 - Assault",
	Tiles =	{
		"$(xcom)/terrain/blanks.*",
		"$(ufo2000)/newmaps/area/roads.*",
		"$(ufo2000)/newmaps/area/urbits.*",
		"$(ufo2000)/newmaps/area/urban.*",
		"$(ufo2000)/newmaps/area/frniture.*",
		"$(ufo2000)/newmaps/area/u_base.*"
	},
	Maps = {
		"$(ufo2000)/newmaps/area/assault01.map",
		"$(ufo2000)/newmaps/area/assault02.map",
		"$(ufo2000)/newmaps/area/assault03.map",
		"$(ufo2000)/newmaps/area/assault04.map",
		"$(ufo2000)/newmaps/area/assault06.map",
		"$(ufo2000)/newmaps/area/assault05.map",
		"$(ufo2000)/newmaps/area/assault07.map",
		"$(ufo2000)/newmaps/area/assault08.map",
		"$(ufo2000)/newmaps/area/assault09.map",
		"$(ufo2000)/newmaps/area/assault10.map",
		"$(ufo2000)/newmaps/area/assault11.map",
		"$(ufo2000)/newmaps/area/assault12.map",
		"$(ufo2000)/newmaps/area/assault13.map",
		"$(ufo2000)/newmaps/area/assault14.map",
		"$(ufo2000)/newmaps/area/assault15.map",
		"$(ufo2000)/newmaps/area/assault16.map"
	},

		MapGenerator = function(map)
 			  if ((map.SizeX == 4) and (map.SizeY == 4)) then
   			  local map_number = math.random(1, 3)

           if map_number == 1 then
               	map. Mapdata = {
			{ 03, -1, 01, -1 },
			{ -1, -1, -1, -1 },
			{ 03, -1, 01, -1 },
			{ -1, -1, -1, -1 },
               }

           elseif map_number == 2 then
               map.Mapdata = {
			{ 09, -1, 11, -1 },
			{ -1, -1, -1, -1 },
			{ 10, -1, 12, -1 },
			{ -1, -1, -1, -1 },
               }

           elseif map_number == 3 then
               map.Mapdata = {
			{ 14, 02, 02, 15 },
			{ 14, 02, 02, 15 },
			{ 14, 02, 02, 15 },
			{ 14, 02, 02, 15 },
               }

           end

           return map
	end

					  if ((map.SizeX == 5) and (map.SizeY == 5)) then
   			  local map_number = math.random(1, 4)

           if map_number == 1 then
               	map. Mapdata = {
		{ 03, -1, 05, 01, -1 },
		{ -1, -1, 05, -1, -1 },
		{ 08, 16, 02, 07, 06 },
		{ 03, -1, 05, 01, -1 },
		{ -1, -1, 05, -1, -1 },
               }

           elseif map_number == 2 then
               map.Mapdata = {
		{ 09, -1, 02, 11, -1 },
		{ -1, -1, 02, -1, -1 },
		{ 02, 14, 13, 15, 02 },
		{ 10, -1, 02, 12, -1 },
		{ -1, -1, 02, -1, -1 },
               }       

           elseif map_number == 3 then
               map.Mapdata = {
		{ 14, 02, 13, 02, 15 },
		{ 02, 14, 02, 15, 02 },
		{ 13, 02, 13, 02, 13 },
		{ 02, 14, 02, 15, 02 },
		{ 14, 02, 13, 02, 15 },
               }       


           elseif map_number == 4 then
               map.Mapdata = {
		{ 02, 14, 02, 15, 02 },
		{ 02, 14, 02, 15, 02 },
		{ 02, 14, 02, 15, 02 },
		{ 02, 14, 02, 15, 02 },
		{ 02, 14, 02, 15, 02 },
               }       


           end

           return map

	end


		if ((map.SizeX == 6) and (map.SizeY == 6)) then
   			  local map_number = math.random(1, 6)

           if map_number == 1 then
               	map. Mapdata = {
		{ 03, -1, 04, -1, 01, -1 },
		{ -1, -1, -1, -1, -1, -1 },
		{ 03, -1, 04, -1, 01, -1 },
		{ -1, -1, -1, -1, -1, -1 },
		{ 03, -1, 04, -1, 01, -1 },
		{ -1, -1, -1, -1, -1, -1 },
               }

           elseif map_number == 2 then
               map.Mapdata = {
		{ 03, -1, 04, -1, 01, -1 },
		{ -1, -1, -1, -1, -1, -1 },
		{ 03, -1, 05, 05, 01, -1 },
		{ -1, -1, 05, 05, -1, -1 },
		{ 03, -1, 04, -1, 01, -1 },
		{ -1, -1, -1, -1, -1, -1 },
               }       

           elseif map_number == 3 then
               map.Mapdata = {
		{ 03, -1, 04, -1, 01, -1 },
		{ -1, -1, -1, -1, -1, -1 },
		{ 08, 16, 02, 02, 07, 06 },
		{ 08, 16, 02, 02, 07, 06 },
		{ 03, -1, 04, -1, 01, -1 },
		{ -1, -1, -1, -1, -1, -1 },
               }       

           elseif map_number == 4 then
               map.Mapdata = {
		{ 09, -1, 02, 02, 11, -1 },
		{ -1, -1, 14, 02, -1, -1 },
		{ 02, 02, 02, 15, 02, 02 },
		{ 02, 02, 14, 02, 02, 02 },
		{ 10, -1, 02, 15, 12, -1 },
		{ -1, -1, 02, 02, -1, -1 },
               }       

           elseif map_number == 5 then
               map.Mapdata = {
		{ 14, 02, 15, 15, 02, 15 },
		{ 02, 02, 14, 14, 02, 02 },
		{ 02, 02, 15, 15, 02, 13 },
		{ 13, 02, 14, 14, 02, 02 },
		{ 02, 02, 15, 15, 02, 02 },
		{ 14, 02, 14, 14, 02, 15 },
               }       

           elseif map_number == 6 then
               map.Mapdata = {
		{ 02, 14, 02, 02, 15, 02 },
		{ 13, 14, 02, 02, 15, 13 },
		{ 02, 14, 02, 02, 15, 02 },
		{ 02, 14, 02, 02, 15, 02 },
		{ 13, 14, 02, 02, 15, 13 },
		{ 02, 14, 02, 02, 15, 02 },
               }       

           end

           return map

	end


	end


}
