AddXcomTerrain {
	Name = "Area 51 - Complex",
	Tiles =	{
		"$(xcom)/terrain/blanks.*",
		"$(ufo2000)/newmaps/area/roads.*",
		"$(ufo2000)/newmaps/area/urbits.*",
		"$(ufo2000)/newmaps/area/urban.*",
		"$(ufo2000)/newmaps/area/frniture.*",
		"$(ufo2000)/newmaps/area/u_base.*"
	},
	Maps = {
		"$(ufo2000)/newmaps/area/complex00.map",
		"$(ufo2000)/newmaps/area/complex01.map",
		"$(ufo2000)/newmaps/area/complex02.map",
		"$(ufo2000)/newmaps/area/complex03.map",
		"$(ufo2000)/newmaps/area/complex04.map",
		"$(ufo2000)/newmaps/area/complex05.map",
		"$(ufo2000)/newmaps/area/complex06.map",
		"$(ufo2000)/newmaps/area/complex07.map",
		"$(ufo2000)/newmaps/area/complex08.map",
		"$(ufo2000)/newmaps/area/complex09.map",
		"$(ufo2000)/newmaps/area/complex10.map",
		"$(ufo2000)/newmaps/area/complex11.map",
		"$(ufo2000)/newmaps/area/complex12.map",
		"$(ufo2000)/newmaps/area/complex13.map",
		"$(ufo2000)/newmaps/area/complex14.map",
		"$(ufo2000)/newmaps/area/complex15.map",
		"$(ufo2000)/newmaps/area/complex16.map",
		"$(ufo2000)/newmaps/area/complex17.map",
		"$(ufo2000)/newmaps/area/complex18.map",
		"$(ufo2000)/newmaps/area/complex19.map",
		"$(ufo2000)/newmaps/area/complex20.map",
		"$(ufo2000)/newmaps/area/complex21.map",
		"$(ufo2000)/newmaps/area/complex22.map",
		"$(ufo2000)/newmaps/area/complex23.map",
		"$(ufo2000)/newmaps/area/complex24.map",
		"$(ufo2000)/newmaps/area/complex25.map",
		"$(ufo2000)/newmaps/area/complex26.map",
		"$(ufo2000)/newmaps/area/complex27.map",
		"$(ufo2000)/newmaps/area/complex28.map",
		"$(ufo2000)/newmaps/area/complex29.map",
		"$(ufo2000)/newmaps/area/complex30.map",
		"$(ufo2000)/newmaps/area/complex31.map",
		"$(ufo2000)/newmaps/area/complex32.map",
		"$(ufo2000)/newmaps/area/complex33.map"



	}
}
