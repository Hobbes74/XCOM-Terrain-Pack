AddXcomTerrain {
	Name = "Area 51 - Skyranger Factory",
	Tiles =	{
		"$(xcom)/terrain/blanks.*",
		"$(ufo2000)/newmaps/area/u_wall02.*",
		"$(ufo2000)/newmaps/area/urban.*",
		"$(ufo2000)/newmaps/area/frniture.*",
		"$(ufo2000)/newmaps/area/plane.*"
	},
	Maps = {
		"$(ufo2000)/newmaps/area/area60.map"
	},

	MapGenerator = function(map)

		if (map.SizeX ~= 6) then map.SizeX = 6 end
		
		if (map.SizeY ~= 6) then map.SizeY = 6 end

		if ((map.SizeX == 6) and (map.SizeY == 6)) then

		map.Mapdata = {
                   		{ 60, -1, -1, -1, -1, -1 },
                   		{ -1, -1, -1, -1, -1, -1 },
                   		{ -1, -1, -1, -1, -1, -1 },
                  		{ -1, -1, -1, -1, -1, -1 },
                   		{ -1, -1, -1, -1, -1, -1 },
                   		{ -1, -1, -1, -1, -1, -1 },
           		    }
	          end

   		return map
    

   end


}