X-COM: UFO Defense Hive terrain Mod version 9.02 by Hobbes

To use the new terrain simply unzip this file into your UFO
directory. It will replace the entire Terror Site terrain with 
the new Hive terrain. (Click Yes when the computer asks if 
you want to replace the files on the folders). 

WARNING: The mod will replace files on the Terrain, Routes and Maps
directories so remember to make back ups of these folders if you 
wish later to return to the game's original configuration (or you can
reinstall it from the game disks). There shouldn't be any problems
but use these files at your own risk. 

Afterwards launch the game and wait for the aliens to launch a terror 
mission (it won't work fully for games saved previously on tactical).

The lastest version can be found at: www.geocities.com/
aadlg/xcom.html

Hobbes

