X-COM: UFO Defense City 2 Terrain Mod version 9.01

This mod adds a twist to the original buildings of the Terror Sites. Instead of them having just
one orientation all building can now face 4 different directions (N, S, W, E). 

Warning: This mod requires Scott T Jones' XComUtil editor to work. If you don't know 
what XComUtil is, check his page at: http://xcomutil.scotttjones.com/

If you have XComUtil 9.60 simply unzip the contents of the city2.zip file to your UFO folder. 
It will ask if you want to replace the XComUtil.cfg file and you must choose yes. 


Afterwards, run XCSetup (XComUtil's setup file). There will be several options for you to 
choose. To enable the City 2 mod, on the option "Do you wish combat terrain to be randomized?"
 choose No and, on "Do you wish to be prompted before a ship attack" you must choose Yes.

Click on RunXCom to start the game. When you send a plane to a Terror site or to an UFO retrieval mission, a prompt will appear and you should choose terrain 5 - Urban.

Have fun :)

The lastest version can be found at: www.geocities.com/
aadlg/xcom.html

The lastest version can be found at: www.geocities.com/
aadlg/xcom.html

Hobbes

