AddXcomTerrain {
	Name = "Slum",
	Tiles =	{
		"$(xcom)/terrain/blanks.*",
		"$(xcom)/terrain/roads.*",
		"$(xcom)/terrain/urbits.*",
		"$(xcom)/terrain/urban.*",
		"$(xcom)/terrain/frniture.*",
		"$(tftd)/terrain/deckc.*",
		"$(tftd)/terrain/linerc.*"

	},
	Maps = {
		"$(ufo2000)/newmaps/slum/slum00.map",
		"$(ufo2000)/newmaps/slum/slum01.map",
		"$(ufo2000)/newmaps/slum/slum02.map",
		"$(ufo2000)/newmaps/slum/slum03.map",
		"$(ufo2000)/newmaps/slum/slum04.map",
		"$(ufo2000)/newmaps/slum/slum05.map",
		"$(ufo2000)/newmaps/slum/slum06.map",
		"$(ufo2000)/newmaps/slum/slum07.map",
		"$(ufo2000)/newmaps/slum/slum08.map",
		"$(ufo2000)/newmaps/slum/slum09.map",
		"$(ufo2000)/newmaps/slum/slum10.map",
		"$(ufo2000)/newmaps/slum/slum11.map",
		"$(ufo2000)/newmaps/slum/slum12.map",
		"$(ufo2000)/newmaps/slum/slum13.map",
		"$(ufo2000)/newmaps/slum/slum14.map",
		"$(ufo2000)/newmaps/slum/slum15.map",
		"$(ufo2000)/newmaps/slum/slum16.map",
		"$(ufo2000)/newmaps/slum/slum17.map",
		"$(ufo2000)/newmaps/slum/slum18.map",
		"$(ufo2000)/newmaps/slum/slum19.map",
		"$(ufo2000)/newmaps/slum/slum20.map",
		"$(ufo2000)/newmaps/slum/slum21.map",
		"$(ufo2000)/newmaps/slum/slum22.map",
		"$(ufo2000)/newmaps/slum/slum23.map",
		"$(ufo2000)/newmaps/slum/slum24.map",
		"$(ufo2000)/newmaps/slum/slum25.map",
		"$(ufo2000)/newmaps/slum/slum26.map",
		"$(ufo2000)/newmaps/slum/slum27.map"

	},
MapGenerator = function(tmp)
		local function add_roads(size_x, size_y, map)
			local x, y, z
	
			if (math.random(1, size_x) ~= 1) then
				x = math.random(1, size_x)
				for i = 1, size_y do map[x][i] =  random {05, 06} end
			end
	
			if (math.random(1, size_y) ~= 1) then
				y = math.random(1, size_y)
				for i = 1, size_x do map[i][y] = random {00, 01, 02} end
			end

	
			if (math.random(1, size_x) ~= 1) then
				z = math.random(1, size_y)
				for i = 1, size_y do map[z][i] =  random {07, 08} end
			end
	
			if (x and y) then
				map[x][y] =  random {03, 04}

			end

			if (z and y) then
				map[z][y] =  9
			end

		end

		local function random_normal()
			return random {23, 24, 25, 26, 27}
		end	

		local function random_double(x, y, map)
			local a = x + 1
			local b = y + 1
			if (map[x][y] > 9 and map[a][y] > 9 and map[x][b] > 9 and map[a][b] > 9) then
				map[x][y] = random {10, 11}
				map[a][y] = -1
				map[x][b] = -1
				map[a][b] = -1
			end

		end

		local function random_triple(x, y, map)
			local b = y + 1
			if (map[x][y] > 21 and map[x][b] > 21) then
				map[x][y] = random {12, 13, 14, 15, 16}
				map[x][b] = -1

			end

		end

		local function random_quadruple(x, y, map)
			local b = y + 1
			local d = y + 2
			if (map[x][y] > 9 and map[x][b] > 21 and map[x][d] > 21) then
				map[x][y] = random {17, 18, 19, 20, 21, 22}
				map[x][b] = -1
				map[x][d] = -1
			end

		end

		for i = 1, tmp.SizeY do
			for j = 1, tmp.SizeX do
				tmp.Mapdata[i][j] = random_normal()
			end
		end

		add_roads(tmp.SizeX, tmp.SizeY, tmp.Mapdata)

		for i = 1, tmp.SizeY - 1 do
			for j = 1, tmp.SizeX - 1 do
				if (math.random(1, 12) > 10) then
					random_double(i, j, tmp.Mapdata)
				end
			end
		end

		for i = 1, tmp.SizeY do
			for j = 1, tmp.SizeX - 1 do
				if (math.random(1, 12) > 8) then
					random_triple(i, j, tmp.Mapdata)
				end
			end
		end

		for i = 1, tmp.SizeY do
			for j = 1, tmp.SizeX - 2 do
				if (math.random(1, 12) > 8) then
					random_quadruple(i, j, tmp.Mapdata)
				end
			end
		end


		return tmp
	end		
}
