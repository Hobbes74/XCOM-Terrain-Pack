AddXcomTerrain {
	Name = "Siberia",
	Tiles =	{
		"$(xcom)/terrain/blanks.*",
		"$(xcom)/terrain/polar.*",
		"$(xcom)/terrain/xbase1.*",
		"$(xcom)/terrain/barn.*"
	},
	Maps = {
		"$(ufo2000)/newmaps/siberia/siberia00.map",
		"$(ufo2000)/newmaps/siberia/siberia01.map",
		"$(ufo2000)/newmaps/siberia/siberia02.map",
		"$(ufo2000)/newmaps/siberia/siberia03.map",
		"$(ufo2000)/newmaps/siberia/siberia04.map",
		"$(ufo2000)/newmaps/siberia/siberia05.map",
		"$(ufo2000)/newmaps/siberia/siberia06.map",
		"$(ufo2000)/newmaps/siberia/siberia07.map",
		"$(ufo2000)/newmaps/siberia/siberia08.map",
		"$(ufo2000)/newmaps/siberia/siberia09.map",
		"$(ufo2000)/newmaps/siberia/siberia10.map",
		"$(ufo2000)/newmaps/siberia/siberia11.map",
		"$(ufo2000)/newmaps/siberia/siberia12.map",
		"$(ufo2000)/newmaps/siberia/siberia13.map",
		"$(ufo2000)/newmaps/siberia/siberia14.map",
		"$(ufo2000)/newmaps/siberia/siberia15.map",
		"$(ufo2000)/newmaps/siberia/siberia16.map",
		"$(ufo2000)/newmaps/siberia/siberia17.map",
		"$(ufo2000)/newmaps/siberia/siberia18.map",
		"$(ufo2000)/newmaps/siberia/siberia19.map",
		"$(ufo2000)/newmaps/siberia/siberia20.map",
		"$(ufo2000)/newmaps/siberia/siberia21.map",
		"$(ufo2000)/newmaps/siberia/siberia22.map",
		"$(ufo2000)/newmaps/siberia/siberia23.map",
		"$(ufo2000)/newmaps/siberia/siberia24.map",
		"$(ufo2000)/newmaps/siberia/siberia25.map",
		"$(ufo2000)/newmaps/siberia/siberia26.map",
		"$(ufo2000)/newmaps/siberia/siberia27.map",
		"$(ufo2000)/newmaps/siberia/siberia28.map",
		"$(ufo2000)/newmaps/siberia/siberia29.map",
		"$(ufo2000)/newmaps/siberia/siberia30.map",
		"$(ufo2000)/newmaps/siberia/siberia31.map",
		"$(ufo2000)/newmaps/siberia/siberia32.map",
		"$(ufo2000)/newmaps/siberia/siberia33.map",
		"$(ufo2000)/newmaps/siberia/siberia34.map",
		"$(ufo2000)/newmaps/siberia/siberia35.map",
		"$(ufo2000)/newmaps/siberia/siberia36.map",
		"$(ufo2000)/newmaps/siberia/siberia37.map",
		"$(ufo2000)/newmaps/siberia/siberia38.map",
		"$(ufo2000)/newmaps/siberia/siberia39.map",
		"$(ufo2000)/newmaps/siberia/siberia40.map",
		"$(ufo2000)/newmaps/siberia/siberia41.map",
		"$(ufo2000)/newmaps/siberia/siberia42.map",
		"$(ufo2000)/newmaps/siberia/siberia43.map",
		"$(ufo2000)/newmaps/siberia/siberia44.map"
	},
MapGenerator = function(tmp)
		local function add_roads(size_x, size_y, map)
			local x, y, w

			if (math.random(1, size_y) ~= 1) then
				w = math.random(1, size_y)
				for i = 1, size_x do map[i][w] = random {27, 28, 29, 30, 31, 				32} end
			end
	
			if (math.random(1, size_x) ~= 1) then
				x = math.random(1, size_x)
				for i = 1, size_y do map[x][i] =  random {00, 01, 02, 03, 					04, 05, 06, 07, 08, 09, 10, 11, 12, 13, 14} end
			end
	
			if (math.random(1, size_y) ~= 1) then
				y = math.random(1, size_y)
				for i = 1, size_x do map[i][y] = random {15, 16, 17, 18, 19, 				20, 21, 22, 23} end
			end

	
			if (x and y) then
				map[x][y] =  random {24, 25, 26}

			end

		end

		local function random_normal()
			return random {33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44}
		end	


		for i = 1, tmp.SizeY do
			for j = 1, tmp.SizeX do
				tmp.Mapdata[i][j] = random_normal()
			end
		end

		add_roads(tmp.SizeX, tmp.SizeY, tmp.Mapdata)


		return tmp
	end		
}
