UFO2000 Native Terrain version 9.03

This terrain requires UFO to be installed with UFO2000. To play 
the new terrain simply unzip this file into the /newmaps directory 
inside the UFO2000 directory. 
