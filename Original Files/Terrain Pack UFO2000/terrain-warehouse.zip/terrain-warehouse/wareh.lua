AddXcomTerrain {
	Name = "Warehouse",
	Tiles =	{
		"$(xcom)/terrain/blanks.*",
		"$(xcom)/terrain/roads.*",
		"$(xcom)/terrain/urbits.*",
		"$(xcom)/terrain/urban.*",
		"$(xcom)/terrain/frniture.*"
	},
	Maps = {
		"$(extension)/wareh00.map",
		"$(extension)/wareh01.map",
		"$(extension)/wareh02.map",
		"$(extension)/wareh03.map",
		"$(extension)/wareh04.map",
		"$(extension)/wareh05.map",
		"$(extension)/wareh06.map",
		"$(extension)/wareh07.map",
		"$(extension)/wareh08.map",
		"$(extension)/wareh09.map",
		"$(extension)/wareh11.map",
		"$(extension)/wareh12.map",
		"$(extension)/wareh13.map",
		"$(extension)/wareh14.map",
		"$(extension)/wareh15.map",
		"$(extension)/wareh16.map",
		"$(extension)/wareh17.map",
		"$(extension)/wareh18.map"
	}
}
