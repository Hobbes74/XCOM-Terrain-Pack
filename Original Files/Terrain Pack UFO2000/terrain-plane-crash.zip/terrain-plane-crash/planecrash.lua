--------------------------------------------------------------------------
--  CRASHED PLANE	Maps TFTD, Code & PCKs Violazr		V 1.1	--
--------------------------------------------------------------------------



AddXcomTerrain {

	Name = "Plane Crash Site",

	Tiles =	{
		"$(xcom)/terrain/blanks.*",
		"$(extension)/planecrash/sands.*",
		"$(extension)/bird.*",
		"$(extension)/planecrash/dummy.*",
	},

	Maps = {
		"$(tftd)/maps/plane00.map",
		"$(tftd)/maps/plane01.map",
		"$(tftd)/maps/plane02.map",
		"$(tftd)/maps/plane03.map",
		"$(extension)/plane04.map",
		"$(extension)/plane05.map",
		"$(extension)/plane06.map",
		"$(extension)/plane07.map",
		"$(extension)/plane08.map",
		"$(extension)/plane09.map",
		"$(extension)/plane10.map",
		"$(extension)/plane11.map",
		"$(tftd)/maps/plane12.map",
		"$(tftd)/maps/plane13.map",
		"$(tftd)/maps/plane14.map",
		"$(tftd)/maps/plane15.map",
		"$(tftd)/maps/plane16.map",
		"$(tftd)/maps/plane17.map",
		"$(tftd)/maps/plane18.map",
		"$(tftd)/maps/plane19.map",
		"$(tftd)/maps/plane20.map",
	},
--41



   MapGenerator = function(map)

		local ys, xs

		map.Mapdata = {
                	   		{ -1, -1, -1, -1, -1, -1 },
                   			{ -1, -1, -1, -1, -1, -1 },
                   			{ -1, -1, -1, -1, -1, -1 },
         	         		{ -1, -1, -1, -1, -1, -1 },
                	   		{ -1, -1, -1, -1, -1, -1 },
                   			{ -1, -1, -1, -1, -1, -1 },
			}


		if ((map.SizeX == 4) or (map.SizeY == 4)) then	-- no 4x4
			map.SizeX, map.SizeY = 5,5
		end
--60


		local function random_sand()		-- maps for seabed/desert
			return random {00, 01, 02, 03}
		end	

		for i = 1, map.SizeY do			-- create seabed/desert
			for j = 1, map.SizeX do
				map.Mapdata[i][j] = random_sand()
			end
		end


		if ((map.SizeX == 6) or (map.SizeY == 6)) then	-- 6x6 shifts
			ys = (math.random(0, 1))
			xs = (math.random(0, 1))
		else
			ys, xs = 0,0
		end


								-- plane body

			map.Mapdata[1+ys][3+xs] = 12


		if (math.random(0, 1)) == 0 then
			map.Mapdata[2+ys][3+xs] = 11
		else
			map.Mapdata[2+ys][3+xs] = 10
		end


		if (math.random(0, 1)) == 0 then
			map.Mapdata[4+ys][3+xs] = 9
		else
			map.Mapdata[4+ys][3+xs] = 8
		end


		if (math.random(0, 1)) == 0 then
			map.Mapdata[3+ys][3+xs] = 7
		else
			map.Mapdata[3+ys][3+xs] = 6
		end


		if (math.random(0, 1)) == 0 then
			map.Mapdata[5+ys][3+xs] = 5
		else
			map.Mapdata[5+ys][3+xs] = 4
		end


								-- plane wings
		if (math.random(0, 1)) == 0 then
			map.Mapdata[3+ys][1+xs] = 20
		else
			map.Mapdata[3+ys][1+xs] = 19
		end


		if (math.random(0, 1)) == 0 then
			map.Mapdata[3+ys][2+xs] = 16
		else
			map.Mapdata[3+ys][2+xs] = 15
		end


		if (math.random(0, 1)) == 0 then
			map.Mapdata[3+ys][4+xs] = 14
		else
			map.Mapdata[3+ys][4+xs] = 13
		end


		if (math.random(0, 1)) == 0 then
			map.Mapdata[3+ys][5+xs] = 18
		else
			map.Mapdata[3+ys][5+xs] = 17
		end





	return map
   end
}