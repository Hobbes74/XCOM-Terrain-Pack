--------------------------------------------------------------------------
--  CRASHED PLANE	Maps TFTD, Code & PCKs Violazr		V 1.1	--
--------------------------------------------------------------------------
--  Look here for more:							--
--  http://www.xcomufo.com/forums/index.php?act=ST&f=269&t=8125&st=0	--
--------------------------------------------------------------------------


This is the implementation of the previously missing TFTD terrain "Sunken Plane", with some new terrain graphics (desert instead of seabed, no bubbles) and tougher walls.

To play it, you will also need TFTD (available as abandonware) installed with UFO2000 because it uses the original maps.


TO INSTALL:

Unzip the downloaded file to your UFO2000 directory (retaining folders)

OR

copy the .lua and the folder into the /newmaps directory
copy BIRD.* into the /tftd/terrain directory
copy overwrite plane##.map in the /tftd/maps directory with the new ones


(The second is required because of an error that happens with the beta if the set is somewhere else, the third replaces certain maps with fixed versions - the originals don't work right in UFO2000)



Enjoy!

-Violazr