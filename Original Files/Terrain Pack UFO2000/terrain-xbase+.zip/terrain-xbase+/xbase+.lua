AddXcomTerrain {
	Name = "XBase+",
	Tiles =	{
		"$(xcom)/terrain/blanks.*",
		"$(xcom)/terrain/xbase1.*",
		"$(xcom)/terrain/xbase2.*",
		"$(xcom)/terrain/forest.*"
	},
	Maps = {
		"$(extension)/xbase+00.map",
		"$(extension)/xbase+01.map",
		"$(extension)/xbase+02.map",
		"$(extension)/xbase+03.map",
		"$(extension)/xbase+04.map",
		"$(extension)/xbase+05.map",
		"$(extension)/xbase+06.map",
		"$(extension)/xbase+07.map",
		"$(extension)/xbase+08.map",
		"$(extension)/xbase+09.map",
		"$(extension)/xbase+10.map",
		"$(extension)/xbase+11.map",
		"$(extension)/xbase+12.map",
		"$(extension)/xbase+13.map",
		"$(extension)/xbase+14.map",
		"$(extension)/xbase+15.map",
		"$(extension)/xbase+16.map",
		"$(extension)/xbase+17.map",
		"$(extension)/xbase+18.map",
		"$(extension)/xbase+19.map",
		"$(extension)/xbase+20.map",
		"$(extension)/xbase+21.map",
		"$(extension)/xbase+22.map"
	}
}
