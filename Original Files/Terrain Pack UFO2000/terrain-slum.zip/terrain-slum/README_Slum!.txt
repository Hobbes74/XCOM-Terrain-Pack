UFO2000 Slum Terrain version 9.02

This terrain requires TFTD to be installed with UFO2000. To play 
the new terrain simply unzip this file into the /newmaps directory 
inside the UFO2000 directory. 
