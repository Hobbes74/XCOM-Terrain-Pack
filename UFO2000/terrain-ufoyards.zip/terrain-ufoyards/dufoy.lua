AddXcomTerrain {
	Name = "Desert - UFO Yard",
	Tiles =	{
		"$(xcom)/terrain/blanks.*",
		"$(xcom)/terrain/desert.*",
		"$(xcom)/terrain/u_bits.*",
		"$(xcom)/terrain/u_disec2.*",
		"$(xcom)/terrain/u_ext02.*",
		"$(xcom)/terrain/u_oper2.*",
		"$(xcom)/terrain/u_pods.*",
		"$(xcom)/terrain/u_wall02.*",
		"$(xcom)/terrain/ufo1.*"
	},
	Maps = {
		"$(extension)/des00.map",
		"$(extension)/des01.map",
		"$(extension)/des02.map",
		"$(extension)/des03.map",
		"$(extension)/des04.map",
		"$(extension)/des05.map",
		"$(extension)/des06.map",
		"$(extension)/des07.map",
		"$(extension)/des08.map",
		"$(extension)/des09.map",
		"$(extension)/des10.map",
		"$(extension)/des11.map",
		"$(extension)/des12.map",
		"$(extension)/des13.map",
		"$(extension)/des14.map",
		"$(extension)/des15.map",
		"$(extension)/des16.map",
		"$(extension)/des17.map",
		"$(extension)/des18.map",
		"$(extension)/des19.map",
		"$(extension)/des20.map"

	},
}