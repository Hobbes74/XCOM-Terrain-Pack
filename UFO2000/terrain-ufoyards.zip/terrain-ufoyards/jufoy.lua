AddXcomTerrain {
	Name = "Jungle - UFO Yard",
	Tiles =	{
		"$(xcom)/terrain/blanks.*",
		"$(xcom)/terrain/jungle.*",
		"$(xcom)/terrain/u_bits.*",
		"$(xcom)/terrain/u_disec2.*",
		"$(xcom)/terrain/u_ext02.*",
		"$(xcom)/terrain/u_oper2.*",
		"$(xcom)/terrain/u_pods.*",
		"$(xcom)/terrain/u_wall02.*",
		"$(xcom)/terrain/ufo1.*"
	},
	Maps = {
		"$(extension)/jun00.map",
		"$(extension)/jun01.map",
		"$(extension)/jun02.map",
		"$(extension)/jun03.map",
		"$(extension)/jun04.map",
		"$(extension)/jun05.map",
		"$(extension)/jun06.map",
		"$(extension)/jun07.map",
		"$(extension)/jun08.map",
		"$(extension)/jun09.map",
		"$(extension)/jun10.map",
		"$(extension)/jun11.map",
		"$(extension)/jun12.map",
		"$(extension)/jun13.map",
		"$(extension)/jun14.map",
		"$(extension)/jun15.map",
		"$(extension)/jun16.map",
		"$(extension)/jun17.map",
		"$(extension)/jun18.map",
		"$(extension)/jun19.map",
		"$(extension)/jun20.map"

	},
}