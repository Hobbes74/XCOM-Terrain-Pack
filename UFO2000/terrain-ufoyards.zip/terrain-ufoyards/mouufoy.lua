AddXcomTerrain {
	Name = "Mountain - UFO Yard",
	Tiles =	{
		"$(xcom)/terrain/blanks.*",
		"$(xcom)/terrain/mount.*",
		"$(xcom)/terrain/u_bits.*",
		"$(xcom)/terrain/u_disec2.*",
		"$(xcom)/terrain/u_ext02.*",
		"$(xcom)/terrain/u_oper2.*",
		"$(xcom)/terrain/u_pods.*",
		"$(xcom)/terrain/u_wall02.*",
		"$(xcom)/terrain/ufo1.*"
	},
	Maps = {
		"$(extension)/mou00.map",
		"$(extension)/mou01.map",
		"$(extension)/mou02.map",
		"$(extension)/mou03.map",
		"$(extension)/mou04.map",
		"$(extension)/mou05.map",
		"$(extension)/mou06.map",
		"$(extension)/mou07.map",
		"$(extension)/mou08.map",
		"$(extension)/mou09.map",
		"$(extension)/mou10.map",
		"$(extension)/mou11.map",
		"$(extension)/mou12.map",
		"$(extension)/mou13.map",
		"$(extension)/mou14.map",
		"$(extension)/mou15.map",
		"$(extension)/mou16.map",
		"$(extension)/mou17.map",
		"$(extension)/mou18.map",
		"$(extension)/mou19.map",
		"$(extension)/mou20.map",
		"$(extension)/mou21.map"


	},
}