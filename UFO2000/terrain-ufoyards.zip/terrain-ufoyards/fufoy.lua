AddXcomTerrain {
	Name = "Forest - UFO Yard",
	Tiles =	{
		"$(xcom)/terrain/blanks.*",
		"$(xcom)/terrain/forest.*",
		"$(xcom)/terrain/u_bits.*",
		"$(xcom)/terrain/u_disec2.*",
		"$(xcom)/terrain/u_ext02.*",
		"$(xcom)/terrain/u_oper2.*",
		"$(xcom)/terrain/u_pods.*",
		"$(xcom)/terrain/u_wall02.*",
		"$(xcom)/terrain/ufo1.*"
	},
	Maps = {
		"$(extension)/for00.map",
		"$(extension)/for01.map",
		"$(extension)/for02.map",
		"$(extension)/for03.map",
		"$(extension)/for04.map",
		"$(extension)/for05.map",
		"$(extension)/for06.map",
		"$(extension)/for07.map",
		"$(extension)/for08.map",
		"$(extension)/for09.map",
		"$(extension)/for10.map",
		"$(extension)/for11.map",
		"$(extension)/for12.map",
		"$(extension)/for13.map",
		"$(extension)/for14.map",
		"$(extension)/for15.map",
		"$(extension)/for16.map",
		"$(extension)/for17.map",
		"$(extension)/for18.map",
		"$(extension)/for19.map",
		"$(extension)/for20.map"

	},
}