AddXcomTerrain {
	Name = "Cydonia - UFO Yard",
	Tiles =	{
		"$(xcom)/terrain/blanks.*",
		"$(xcom)/terrain/mars.*",
		"$(xcom)/terrain/u_bits.*",
		"$(xcom)/terrain/u_disec2.*",
		"$(xcom)/terrain/u_ext02.*",
		"$(xcom)/terrain/u_oper2.*",
		"$(xcom)/terrain/u_pods.*",
		"$(xcom)/terrain/u_wall02.*",
		"$(xcom)/terrain/ufo1.*"
	},
	Maps = {
		"$(extension)/cyd00.map",
		"$(extension)/cyd01.map",
		"$(extension)/cyd02.map",
		"$(extension)/cyd03.map",
		"$(extension)/cyd04.map",
		"$(extension)/cyd05.map",
		"$(extension)/cyd06.map",
		"$(extension)/cyd07.map",
		"$(extension)/cyd08.map",
		"$(extension)/cyd09.map",
		"$(extension)/cyd10.map",
		"$(extension)/cyd11.map",
		"$(extension)/cyd12.map",
		"$(extension)/cyd13.map",
		"$(extension)/cyd14.map",
		"$(extension)/cyd15.map",
		"$(extension)/cyd16.map",
		"$(extension)/cyd17.map",
		"$(extension)/cyd18.map",
		"$(extension)/cyd19.map"
		
	},
}