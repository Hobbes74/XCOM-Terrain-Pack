Arctic - UFO Yard
Desert - UFO Yard
Forest - UFO Yard
Jungle - UFO Yard
Mountain - UFO Yard
Cydonia - UFO Yard

copy and paste the folders and lua. files to new maps.
Something like this (C:\Program Files\Ufo2000\newmaps)

Enjoy :) -Plasma

All terrains updated