UFO2000 Railyard Terrain version 9.02

This terrain requires TFTD to be installed with UFO2000. To play 
the new terrain simply unzip this file into the /newmaps directory 
inside the UFO2000 directory. 

Tips:
- The tunnel walls can be breached with explosives.
- The white pillars, blocks and tire piles can't be destroyed with plasma.
