This is an update of my mothership map
Copy and paste the mothership00.map and mothership lua into the
new maps folder of UFO2000.

-Plasma "Enjoy!" :)