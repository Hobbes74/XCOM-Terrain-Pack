return {
	Name = "DownTown",
	SizeX = 4, SizeY = 4,
	Mapdata = {
		{ 05, 15, -1, 11 },
		{ 02, -1, -1, 10 },
		{ 09, 09, 09, 09 },
		{ 00, 00, 00, 00 },
	}
}
