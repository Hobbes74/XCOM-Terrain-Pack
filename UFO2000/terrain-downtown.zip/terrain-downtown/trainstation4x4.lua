return {
	Name = "DownTown",
	SizeX = 4, SizeY = 4,
	Mapdata = {
		{ 12, 08, -1, 12 },
		{ 10, -1, -1, 10 },
		{ 11, 17, 16, 11 },
		{ 10, 00, 00, 10 },
	}
}
