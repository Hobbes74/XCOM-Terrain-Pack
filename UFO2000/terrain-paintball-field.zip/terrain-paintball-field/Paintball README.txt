--------------------------------------------------------------------------
--  PAINTBALL FIELD		c 2005 by Violazr		V 1.0	--
--------------------------------------------------------------------------
--  Visit the UFO2000 Map Depot:  http://area51.xcomufo.com/depot.htm 	--
--------------------------------------------------------------------------


This map was designed with the aim not only to look like a paintball field, but most of all to encourage paintball-like strategies. Many of the usual approaches, like blowing cover and then scout-sniping, WON'T work. The key here is to outflank the enemy, and preventing him to do it to you.

All coloured obstacles are indestructible. Those of half height are just low enough to fire over, and will provide VERY good cover when ducking. - Shots will have to be aimed at the very top of the opponent's head to hit.
You may want to limit explosives to make that cover even better.

There is a random chance for each terrain size to have towers at fixed positions. Playing with them will add another twist to strategy.


Now get out there and re-learn your game! ;)