Copy and Paste the Folder ab and ab.lua into the newmaps folder of ufo2000

Have Fun! :D
-Abyssion